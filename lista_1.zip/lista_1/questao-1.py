import math


class Client:
    def __init__(self, name, pay):
        self.name = name
        self.pay = pay
        self.next = None
        self.prev = None


class Cashier:
    def __init__(self):
        self.head = None
        self.tail = None
        self.count = 0

    def got_in_line(self, name, pay):
        client = Client(name, pay)
        if self.tail:
            self.tail.next = client
            client.prev = self.tail
            self.tail = client
        else:
            self.head = client
            self.tail = client

    def got_in_line_many(self, input_list):
        if input_list:
            curr_client = input_list.head
            while curr_client:
                self.got_in_line(curr_client.name, curr_client.pay)
                curr_client = curr_client.next

    def call_next(self):
        if self.head is None:
            return
        self.count += self.head.pay
        self.head = self.head.next
        if self.head is not None:
            self.head.prev = None
        else:
            self.tail = None

    def reverse_list(self):
        curr_client = self.head
        while curr_client is not None:
            next_node = curr_client.next
            curr_client.next = curr_client.prev
            curr_client.prev = next_node
            curr_client = next_node
        self.head, self.tail = self.tail, self.head
        return self

    def remove_and_return_half_reverse(self):
        length = 0
        curr_client = self.head
        while curr_client:
            length += 1
            curr_client = curr_client.next

        half = int(math.ceil(length / 2))
        curr_client = self.head
        for i in range(half - 1):
            curr_client = curr_client.next

        second_half = Cashier()
        if curr_client:
            aux_curr_client = curr_client
            while aux_curr_client:
                second_half.got_in_line(
                    aux_curr_client.name, aux_curr_client.pay)
                aux_curr_client = aux_curr_client.next

            if curr_client.prev is not None:
                curr_client.prev.next = None
            else:
                self.head = None
                self.tail = None

            second_half = second_half.reverse_list()

            return second_half


def main():
    cashier_1 = Cashier()
    cashier_2 = Cashier()
    stop_condition = False
    while not stop_condition:
        command_line = input().split(' ')
        # ENTROU
        if command_line[0] == 'ENTROU:':
            if command_line[2] == '1':
                cashier_1.got_in_line(command_line[1], float(command_line[3]))
                print(f'{command_line[1]} entrou na fila 1')
            elif command_line[2] == '2':
                cashier_2.got_in_line(command_line[1], float(command_line[3]))
                print(f'{command_line[1]} entrou na fila 2')
        # PROXIMO
        if command_line[0] == 'PROXIMO:':
            if command_line[1] == '1':
                if cashier_1.head:
                    print(f'{cashier_1.head.name} foi chamado para o caixa 1')
                    cashier_1.call_next()
                else:
                    half_reverse_line_cashier_2 = cashier_2.remove_and_return_half_reverse()
                    cashier_1.got_in_line_many(half_reverse_line_cashier_2)
                    if cashier_1.head:
                        print(f'{cashier_1.head.name} foi chamado para o caixa 1')
                        cashier_1.call_next()
            elif command_line[1] == '2':
                if cashier_2.head:
                    print(f'{cashier_2.head.name} foi chamado para o caixa 2')
                    cashier_2.call_next()
                else:
                    half_reverse_line_cashier_1 = cashier_1.remove_and_return_half_reverse()
                    cashier_2.got_in_line_many(half_reverse_line_cashier_1)
                    if cashier_2.head:
                        print(f'{cashier_2.head.name} foi chamado para o caixa 2')
                        cashier_2.call_next()
        # FIM
        if command_line[0] == 'FIM':
            stop_condition = True
            print('Caixa 1: R$ {:.2f}, Caixa 2: R$ {:.2f}'.format(
                cashier_1.count, cashier_2.count))


main()
